## Portfolio Monitoring and Analytics

This app helps in tracking, monitoring the day to day changes and in-depth reporting

#### License

MIT