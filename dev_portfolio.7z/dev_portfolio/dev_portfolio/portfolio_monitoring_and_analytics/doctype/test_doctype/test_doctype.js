// Copyright (c) 2023, Panigrahis.com and contributors
// For license information, please see license.txt

// frappe.ui.form.on("Test DocType", {
// 	refresh(frm) {

// 	},
// });

/* frappe.ui.form.on("Test DocType", {
     	refresh(frm) {
            $(".title-area").hide();
            $(".level-item.bold.ellipsis").hide();
            //level-item.bold.ellipsis
     	},
     }); */