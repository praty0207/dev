# Copyright (c) 2023, Panigrahis.com and Contributors
# See license.txt

# import frappe
from frappe.tests.utils import FrappeTestCase


class TestCompany(FrappeTestCase):
	pass
