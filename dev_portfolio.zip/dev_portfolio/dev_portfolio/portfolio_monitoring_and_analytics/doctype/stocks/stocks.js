// Copyright (c) 2023, Panigrahis.com and contributors
// For license information, please see license.txt

// frappe.ui.form.on("Stocks", {
// 	refresh(frm) {

// 	},
// });
